
#pragma once

#if defined(ECCS_BEGIN) || defined(ECCS_END) || defined(ECCS) || defined(USING_ECCS)
#error namespace conflicts
#endif

#define ECCS_BEGIN namespace EchoControlSDK {
#define ECCS_END }
#define ECCS ::EchoControlSDK::
#define USING_ECCS using namespace EchoControlSDK;


// Windows: x86_x64 _WIN32 & _WIN64 is defined. x86: _WIN32 is defined only
#if !defined(_WIN32) && !defined(__linux__)
#error platform unsupported
#endif


#if defined(UNICODE) || defined(_UNICODE)
#error unicode unsupported
#endif


#if defined(_MSC_VER)
#  if (_MSC_VER >= 1800)    // >= vc140
#    define SUPPORT_C11 1
#  elif (_MSC_VER != 1600)  // = vc100
#    error compiler unsupported
#  endif
#else
#  if (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 9))
#    define SUPPORT_C11 1
#  else
#    error compiler unsupported
#  endif
#endif


#ifdef SUPPORT_C11
#ifndef ECCS_C11
#  define ECCS_C11 ::std::
#endif
#else
#  define ECCS_C11 ::boost::
#endif


#define UNUSED(arg) (arg)


#ifdef SUPPORT_C11
#  define NON_COPYABLE(classname) \
       classname(const classname &) = delete; \
       classname & operator=(const classname &) = delete;
#else
#  define NON_COPYABLE(classname) \
       classname(const classname &); \
       classname & operator=(const classname &);
#endif
//�Ƿ�ر���־��¼���ܣ� 1���رգ�0����
#define DISABLE_LOG 0
//�������ƴ����Ƿ��ӡ�߳���Դ�����Ϣ��DEBUG��־: 1/���� 0/�ر�
#define THREAD_DEBUG_LOG 0
//����������ʱ�������ӵ�log��Ϣ�Ƿ���ʾ
#define TMP_DEBUG_LOG 0

#include "types.h"