// src/config/ConfigTypes.h
#pragma once

#include <string>
#include <cstdint>
#include "../global.h"

ECCS_BEGIN

    // -------------------- �������� --------------------
    struct NetworkConfig {
        std::string host = "127.0.0.1";
        uint16_t    port = 0;

        bool        useUDP = false;

        uint32_t    connectTimeoutMs = 3000;
        uint32_t    retryCount = 3;
        uint32_t    heartbeatIntervalMs = 1000;
    };

    // -------------------- �豸���� --------------------
    struct DeviceConfig {
        std::string deviceId;
        std::string deviceType;
    };

    // -------------------- ��־���� --------------------
    struct LogConfig {
        int logLevel = 1; // INFO
    };

    // -------------------- SDK ������ --------------------
    struct SDKConfig {
        NetworkConfig network;
        DeviceConfig  device;
        LogConfig     log;
    };

ECCS_END
